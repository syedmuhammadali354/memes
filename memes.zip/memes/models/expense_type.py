from odoo import fields, models, api


class Expense(models.Model):
    _name = 'memes.expense.type'
    _description = 'Expense Type Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Expense Type')