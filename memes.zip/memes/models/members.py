from odoo import fields, models, api, _
from dateutil.relativedelta import relativedelta
from datetime import date
from datetime import datetime
from odoo.exceptions import ValidationError


class Member(models.Model):
    _name = 'memes.member'
    _description = 'Member Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _inherits = {'res.partner': 'partner_id'}

    @api.onchange('first_name', 'last_name')
    def _get_member_name(self):
        for member in self:
            member.name = (member.first_name or '') + ' ' + (member.last_name or '')

    @api.onchange('dob')
    def set_age(self):
        for rec in self:
            if rec.dob:
                dt = rec.dob
                d1 = datetime.strptime(str(dt), "%Y-%m-%d").date()
                d2 = date.today()
                rd = relativedelta(d2, d1)
                rec.age = str(rd.years) + ' years'

    first_name = fields.Char('First Name', required=True, track_visibility='onchange')
    last_name = fields.Char('Last Name', track_visibility='onchange')
    age = fields.Char('Age in Numbers')
    dob = fields.Date('Date of Birth')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')], default='male',
                              string='Gender', track_visibility='onchange')
    nationality_name = fields.Char(related='nationality.name')
    cnic = fields.Char('CNIC No', size=15, track_visibility='onchange')
    passport = fields.Char('Passport No', track_visibility='onchange')
    religion = fields.Selection([('muslim', 'Muslim'), ('non', 'Non Muslim')], default='muslim', string='Religion')
    joining = fields.Date('Joining Date', track_visibility='onchange')
    amount_paid = fields.Integer('Amount Paid', track_visibility='onchange', compute="_get_amount_paid")
    personal_expense = fields.Integer('Total expense', track_visibility='onchange', compute="_get_personal_expense")
    active = fields.Boolean(default=True)
    mobile = fields.Char('Mobile No')

    total_paid = fields.Integer('Total Paid', default=0, compute='_get_total_paid')

    arrears = fields.Integer('Arrears', compute='_get_out_arr')
    outstanding_amount = fields.Integer('Outstanding', compute='_get_out_arr')

    arrears_paid = fields.Integer('Arrears Paid', default=0)
    outstanding_cleared = fields.Integer('Outstanding Cleared', default=0)

    partner_id = fields.Many2one('res.partner', 'Partner', required=True, ondelete="cascade")
    nationality = fields.Many2one('res.country', ondelete='restrict', track_visibility='onchange')

    paid_by_ids = fields.One2many(
        comodel_name='memes.expense',
        inverse_name='paid_by',
        string='Paid Expense',
        required=False)

    attendee_ids = fields.Many2many(
        comodel_name='memes.expense',
        inverse_name='attendees',
        string='Attendees')

    def name_get(self):
        res = []
        for record in self:
            name = record.first_name + " " + record.last_name
            res.append((record.id, name))
        return res

    # def pay_arrears(self):
    #     for rec in self:
    #         if rec.arrears > 0:
    #             rec.arrears_paid += rec.arrears
    #
    # def clear_outstanding(self):
    #     for rec in self:
    #         if rec.outstanding_amount > 0:
    #             rec.outstanding_cleared += rec.outstanding_amount

    @api.model
    def create(self, vals):
        if vals.get('mobile') and '-' not in vals.get('mobile'):
            mobile = vals.get('mobile')
            vals['mobile'] = mobile[:4] + '-' + mobile[4:]
        return super(Member, self).create(vals)

    def write(self, vals):
        if vals.get('mobile') and '-' not in vals.get('mobile'):
            mobile = vals.get('mobile')
            vals['mobile'] = mobile[:4] + '-' + mobile[4:]
        return super(Member, self).write(vals)

    def unlink(self):
        # result = []
        # for rec in self:
        #     result.append(rec.partner_id.id)
        # self.env['res.partner'].sudo().search([('id', 'in', result)]).unlink()
        results = []
        for rec in self:
            results.append(rec.id)
            if rec.personal_expense or rec.total_paid > 0:
                raise ValidationError(_(' This record cannot be deleted....!'))
            return super(Member, self).unlink()

    @api.depends('amount_paid', 'personal_expense', 'arrears_paid', 'outstanding_cleared')
    def _get_out_arr(self):
        for rec in self:
            total_cost = rec.amount_paid - rec.personal_expense + rec.arrears_paid - rec.outstanding_cleared
            if total_cost >= 0:
                rec.outstanding_amount = total_cost
                rec.arrears = 0
            else:
                rec.arrears = -total_cost
                rec.outstanding_amount = 0

    @api.depends('attendee_ids.per_head_expense')
    def _get_personal_expense(self):
        for rec in self:
            sum1 = 0
            for attendee in rec.attendee_ids:
                sum1 += attendee.per_head_expense
            rec.personal_expense = sum1

    @api.depends("paid_by_ids.amount")
    def _get_amount_paid(self):
        for rec in self:
            sum1 = 0
            for paid_by in rec.paid_by_ids:
                sum1 += paid_by.amount
            rec.amount_paid = sum1

    @api.depends('amount_paid', 'arrears_paid', 'outstanding_cleared')
    def _get_total_paid(self):
        for rec in self:
            rec.total_paid = rec.amount_paid + rec.arrears_paid - rec.outstanding_cleared
