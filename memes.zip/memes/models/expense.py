from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError


class Expense(models.Model):
    _name = 'memes.expense'
    _description = 'Expense Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'paid_by'

    # attendees = fields.Many2many('memes.member', 'Attendees')
    paid_by = fields.Many2one(
        comodel_name='memes.member',
        string='Paid by',
        required=False)

    attendees = fields.Many2many(
        comodel_name='memes.member',
        string='Attendees')

    # expense_types = fields.Many2many('memes.expense.type', 'Expense Type')
    expense_types = fields.Many2one(
        comodel_name='memes.expense.type',
        string='Expense Types',
        required=False)
    # paid_by = fields.Many2one('memes.member', 'Paid By')

    amount = fields.Integer('Total Amount')
    per_head_expense = fields.Float('Per Head', compute="_get_per_head", default=0)
    expense_date = fields.Date('Expense Date', default=fields.Date.today)

    _sql_constraints = [
        ('expense_uniq', 'unique(paid_by, expense_types, amount, expense_date)', 'This type of data already exists'),
    ]

    @api.depends('amount')
    def _get_per_head(self):
        for rec in self:
            if rec.attendees:
                rec.per_head_expense = rec.amount / len(rec.attendees)

    # @api.onchange('amount')
    # def _get_amount(self):
    #     for rec in self:
    #         if rec.per_head_expense > 0:
    #             rec.paid_by.expense -= rec.per_head_expense*len(rec.attendees)
    #             for attendee in rec.attendees:
    #                 attendee.per_head -= rec.per_head_expense
    #         rec.paid_by.expense += rec.amount
    #
    #         if rec.attendees:
    #             rec.per_head_expense = rec.amount/len(rec.attendees)
    #
    # @api.onchange('per_head_expense')
    # def _get_expense(self):
    #     for rec in self:
    #         for attendee in rec.attendees:
    #             attendee.per_head += rec.per_head_expense

    @api.constrains('paid_by', 'expense_date', 'expense_types', 'amount')
    def _cons(self):
        for rec in self:
            record = self.env['memes.expense'].search(
                [('paid_by', '=', rec.paid_by.id), ('id', '!=', rec.id),
                 ('expense_date', '=', rec.expense_date),
                 ('amount', '=', rec.amount), ('expense_types', '=', rec.expense_types.id)])
        if record:
            raise ValidationError(_(' This record already exits...!!!'))



