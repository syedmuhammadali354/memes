import pdb
import time
from odoo import api, fields, models, _, tools
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class Outstanding(models.TransientModel):
    _name = 'memes.outstanding'
    _description = 'Member Outstanding'

    def _get_outstanding(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        return member_id.outstanding_amount

    outstanding = fields.Integer('Enter Outstanding you want to clear', default=_get_outstanding)

    def outstanding_clear(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        self.ensure_one()
        [data] = self.read()
        clear = data['outstanding']
        member_id.outstanding_cleared += clear

    @api.constrains('outstanding')
    def _cons(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        for rec in self:
            if rec.outstanding > member_id.outstanding_amount or rec.outstanding < 0:
                raise ValidationError(_('Please Enter  Correct Amount...!!!'))




    # # @api.multi
    # def print_report(self):
    #     self.ensure_one()
    #     [data] = self.read()
    #
    #     return self.env.ref('memes.action_report_member_expense').with_context(
    #         landscape=False).report_action(self, data=datas, config=False)

