import pdb
import time
from odoo import api, fields, models, _, tools
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging

_logger = logging.getLogger(__name__)


class MemberExpense(models.TransientModel):
    _name = 'memes.member.expense'
    _description = 'Member Expense'

    cost = fields.Integer('Cost')
    expenses_date = fields.Date('Expense Date', default=fields.Date.today)
    # @api.depends('change_state', 'change_state.amount')
    # def _change_amount(self):
    #     for rec in self:
    #         if rec.change_state.attendees:
    #             if rec.change_state.amount > 1000:
    #                 print(rec.change_state.amount)
    #
    # @api.multi
    def print_report(self):
        self.ensure_one()
        [data] = self.read()
        datas = {
            'ids': [],
            'form': data
        }

        return self.env.ref('memes.action_report_member_expense').with_context(
            landscape=False).report_action(self, data=datas, config=False)

