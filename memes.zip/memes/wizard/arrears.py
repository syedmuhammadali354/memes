import pdb
import time
from odoo import api, fields, models, _, tools
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import logging
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)


class Arrears(models.TransientModel):
    _name = 'memes.arrears'
    _description = 'Member Arrears'

    def _get_arrears(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        return member_id.arrears

    arrears = fields.Integer('Enter Arrears you want to pay', default=_get_arrears)

    def pay_arrears(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        self.ensure_one()
        [data] = self.read()
        clear = data['arrears']
        member_id.arrears_paid += clear

    @api.constrains('arrears')
    def _cons(self):
        member_id = self.env['memes.member'].browse(self.env.context.get('active_ids'))
        for rec in self:
            if rec.arrears > member_id.arrears or rec.arrears < 0:
                raise ValidationError(_('Please Enter  Correct Arrears...!!!'))



    # # @api.multi
    # def print_report(self):
    #     self.ensure_one()
    #     [data] = self.read()
    #
    #     return self.env.ref('memes.action_report_member_expense').with_context(
    #         landscape=False).report_action(self, data=datas, config=False)

