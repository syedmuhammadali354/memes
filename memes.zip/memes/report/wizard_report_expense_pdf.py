import pdb
from odoo import api, fields, models, _
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
from pytz import timezone, utc
import time
import logging
_logger = logging.getLogger(__name__)


class ExpenseManagementSearchReport(models.AbstractModel):
    _name = 'report.memes.wizard_report_expense_pdf'
    _description = 'Expense Records'

    @api.model
    def _get_report_values(self, docsid, data=None):

        # number = data['form']['number'] and data['form']['number'] or False
        costs = data['form']['cost'] or False
        expense_dates = data['form']['expenses_date'] or False
        record_ids = self.env['memes.expense'].search(
            [('amount', '>=', costs), ('expense_date', '=',expense_dates)])
        docargs = {
            'doc_ids': [],
            'date': expense_dates or False,
            'records': record_ids or False,
            'cost': costs or 0,
        }
        return docargs