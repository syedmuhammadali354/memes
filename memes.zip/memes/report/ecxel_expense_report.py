import pdb
import time
from datetime import date
import datetime
from datetime import timedelta
from dateutil import relativedelta
from odoo import tools
from odoo import api, fields, models, _

import logging

_logger = logging.getLogger(__name__)

from io import StringIO
import io

try:
    import xlwt
except ImportError:
    _logger.debug('Cannot `import xlwt`.')

try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')

try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')


class MemberExoenseRep(models.TransientModel):
    _name = 'member.expense.rep'
    _description = 'Member Expense Report'

    cost = fields.Integer('Cost')
    # att = fields.Integer('Att')
    # att1 = fields.Integer('att1')

    # count = fields.Integer('count')
    # paidby = fields.Char('paid')

    # total = fields.Integer('total')

    # @api.multi
    def make_excel(self):
        # ***** Excel Related Statements *****#
        workbook = xlwt.Workbook(encoding="utf-8")
        worksheet = workbook.add_sheet("Expense Report")

        style_title = xlwt.easyxf(
            "font:height 300; font: name Liberation Sans, bold on,color white; align: horiz center;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour grey_ega;")
        style_title2 = xlwt.easyxf(
            "font:height 200; font: name Liberation Sans, bold on,color black; align: horiz center;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour silver_ega;")
        style_table_header = xlwt.easyxf(
            "font:height 150; font: name Liberation Sans, bold on,color black; align: horiz left;borders: left thin, right thin, top thin, bottom thin; pattern: pattern solid, fore_colour cyan_ega;")
        style_table_totals = xlwt.easyxf(
            "font:height 150; font: name Liberation Sans, bold on,color black; align: horiz left;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour cyan_ega;")
        style_date_col = xlwt.easyxf(
            "font:height 180; font: name Liberation Sans,color black; align: horiz left;")
        style_date_col2 = xlwt.easyxf(
            "font:height 180; font: name Liberation Sans,color black; align: horiz right;borders: left thin, right thin, top thin, bottom thin;")

        worksheet.write_merge(0, 2, 0, 6, "Members Expenses ", style=style_title)

        col_0 = worksheet.col(0)
        col_0.width = 256 * 7
        col_1 = worksheet.col(1)
        col_1.width = 256 * 18
        col_2 = worksheet.col(2)
        col_2.width = 256 * 15
        col_3 = worksheet.col(3)
        col_3.width = 256 * 95
        col_4 = worksheet.col(4)
        col_4.width = 256 * 15
        col_5 = worksheet.col(5)
        col_5.width = 256 * 15
        col_6 = worksheet.col(6)
        col_6.width = 256 * 15

        recs = False
        att = False
        row = 3
        col = 0
        # ***** Table Heading *****#
        table_header = ['SR. #', 'Name', 'Expense Type', 'Attendees', 'Cost', 'Date', 'Per Head Amount']
        for i in range(7):
            worksheet.write(row, col, table_header[i], style=style_table_header)
            col += 1
        recs = False

        self.ensure_one()
        [data] = self.read()
        cost = data['cost']

        recs = self.env['memes.expense'].search([('per_head_expense', '>=', cost)])
        # att = self.env['memes.expense'].create({'attendees_id' == 'paid_by_id'})
        i = 1
        if recs:
            total_expense = 0
            total_attendees = []
            total_paid_by = []
            total_dates = []
            for rec in recs:
                row += 1
                col = 0
                total_expense += rec.amount
                if rec.expense_date not in total_dates:
                    total_dates.append(rec.expense_date)
                if rec.paid_by not in total_paid_by:
                    total_paid_by.append(rec.paid_by)
                if rec.attendees not in total_attendees:
                    total_attendees.append(rec.attendees)

                worksheet.write(row, col, i, style=style_date_col)
                col += 1
                worksheet.write(row, col, str(rec.paid_by.name), style=style_date_col)
                col += 1
                worksheet.write(row, col, str(rec.expense_types.name), style=style_date_col)
                col += 1
                worksheet.write(row, col, ", ".join([attendee.name for attendee in rec.attendees]),
                                style=style_date_col)
                col += 1
                worksheet.write(row, col, rec.amount, style=style_date_col)
                col += 1
                worksheet.write(row, col, rec.expense_date, style=style_date_col)
                col += 1
                worksheet.write(row, col, rec.per_head_expense, style=style_date_col)
                col += 1
                i += 1
            row += 2
            total_days = len(total_dates)
            total_attendees = len(total_attendees)
            total_paid_by = len(total_paid_by)

            worksheet.write_merge(row, row, 2, 3, 'Summary of Members Expense')
            row += 1
            summary_headings = ['Total Payee', 'Total Attendees', 'Total Expenses', 'Total Days']
            for i in range(len(summary_headings)):
                worksheet.write(row,2,summary_headings[i], style=style_title2)
                row += 1
                col += 1
            update_row = len(summary_headings)
            row = row - update_row
            worksheet.write(row,3,str(total_paid_by), style=style_date_col)
            row += 1
            worksheet.write(row, 3, str(total_attendees), style=style_date_col)
            row += 1
            worksheet.write(row, 3, str(total_expense), style=style_date_col)
            row += 1
            worksheet.write(row,3,str(total_days), style=style_date_col)
            row += 1

        # *** Member Sheet **** #

        worksheet_member = workbook.add_sheet("Members Report")

        style_title = xlwt.easyxf(
            "font:height 300; font: name Liberation Sans, bold on,color white; align: horiz center;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour grey_ega;")
        style_title2 = xlwt.easyxf(
            "font:height 200; font: name Liberation Sans, bold on,color black; align: horiz center;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour silver_ega;")
        style_table_header = xlwt.easyxf(
            "font:height 150; font: name Liberation Sans, bold on,color black; align: horiz left;borders: left thin, right thin, top thin, bottom thin; pattern: pattern solid, fore_colour cyan_ega;")
        style_table_totals = xlwt.easyxf(
            "font:height 150; font: name Liberation Sans, bold on,color black; align: horiz left;borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour cyan_ega;")
        style_date_col = xlwt.easyxf(
            "font:height 180; font: name Liberation Sans,color black; align: horiz left;")
        style_date_col2 = xlwt.easyxf(
            "font:height 180; font: name Liberation Sans,color black; align: horiz right;borders: left thin, right thin, top thin, bottom thin;")

        worksheet_member.write_merge(0, 2, 0, 7, "Members Report ", style=style_title)

        col_0 = worksheet_member.col(0)
        col_0.width = 256 * 7
        col_1 = worksheet_member.col(1)
        col_1.width = 256 * 25
        col_2 = worksheet_member.col(2)
        col_2.width = 256 * 7
        col_3 = worksheet_member.col(3)
        col_3.width = 256 * 10
        col_4 = worksheet_member.col(4)
        col_4.width = 256 * 15
        col_5 = worksheet_member.col(5)
        col_5.width = 256 * 15
        col_6 = worksheet_member.col(6)
        col_6.width = 256 * 15

        row = 3
        col = 0
        # ***** Table Heading *****#
        table_header = ['SR. #', 'Name', 'Gender', 'Date', 'Total Paid', 'Total Expense', 'Outstanding', 'Arrears']
        for i in range(8):
            worksheet_member.write(row, col, table_header[i], style=style_table_header)
            col += 1
        # recs = False

        # self.ensure_one()
        # [data] = self.read()
        # cost = data['cost']
        #
        # recs = self.env['memes.expense'].search([('per_head_expense', '>=', cost)])
        # # att = self.env['memes.expense'].create({'attendees_id' == 'paid_by_id'})
        i = 1
        recs = self.env['memes.member'].search([])
        if recs:
            # total_expense = 0
        #     total_attendees = []
        #     total_paid_by = []
        #     total_dates = []
            for rec in recs:
                row += 1
                col = 0
                worksheet_member.write(row, col, i, style=style_date_col)
                col += 1
                worksheet_member.write(row, col, str(rec.first_name + " "+ rec.last_name), style=style_date_col)
                col += 1
                worksheet_member.write(row, col, str(rec.gender), style=style_date_col)
                col += 1
                worksheet_member.write(row, col, str(rec.joining),
                                style=style_date_col)
                col += 1
                worksheet_member.write(row, col, rec.total_paid, style=style_date_col)
                col += 1
                worksheet_member.write(row, col, rec.personal_expense, style=style_date_col)
                col += 1
                worksheet_member.write(row, col, rec.outstanding_amount, style=style_date_col)
                col += 1
                worksheet_member.write(row, col, rec.arrears, style=style_date_col)
                i += 1
            # row += 2
            # total_days = len(total_dates)
            # total_attendees = len(total_attendees)
            # total_paid_by = len(total_paid_by)
            #
            # worksheet_member.write_merge(row, row, 2, 3, 'Summary of Members Expense')
            # row += 1
            # summary_headings = ['Total Payee', 'Total Attendees', 'Total Expenses', 'Total Days']
            # for i in range(len(summary_headings)):
            #     worksheet_member.write(row, 2, summary_headings[i], style=style_title2)
            #     row += 1
            #     col += 1
            # update_row = len(summary_headings)
            # row = row - update_row
            # worksheet_member.write(row, 3, str(total_paid_by), style=style_date_col)
            # row += 1
            # worksheet_member.write(row, 3, str(total_attendees), style=style_date_col)
            # row += 1
            # worksheet_member.write(row, 3, str(total_expense), style=style_date_col)
            # row += 1
            # worksheet_member.write(row, 3, str(total_days), style=style_date_col)
            # row += 1

        file_data = io.BytesIO()
        workbook.save(file_data)
        wiz_id = self.env['member.expense.excel.report'].create({
            'data': base64.encodebytes(file_data.getvalue()),
            'name': 'Member expense report.xls'
        })

        return {
            'type': 'ir.actions.act_window',
            'name': 'Member and Expense Report',
            'res_model': 'member.expense.excel.report',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': wiz_id.id,
            'target': 'new'
        }


class MemberExpenseWizard(models.TransientModel):
    _name = "member.expense.excel.report"
    _description = 'Member Expense Excel Report'

    name = fields.Char('filename', readonly=True)
    data = fields.Binary('file', readonly=True)
