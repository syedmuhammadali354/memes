# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'mems',
    'version': '1.4',
    'sequence': 0,
    'summary': 'Member Expense Management System',
    'description': "Hostel-Member Expenses",
    'website': 'https://www.aarso.com',
    'depends': [
        'base',
        'mail',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/menue.xml',
        'wizard/outstanding.xml',
        'wizard/arrears.xml',
        'views/member.xml',
        'views/expense_type.xml',
        'views/expense.xml',
        'report/report.xml',
        'report/expense_report.xml',
        'wizard/wizard_view.xml',
        'report/wizard_report_expense_pdf.xml',
        'report/excel_expense_report.xml',

    ],
    'installable': True,
    'application': True,

}
